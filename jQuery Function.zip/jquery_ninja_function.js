// HIDE CLICK
$(document).ready(function(){
    $('img').click(function(){
        $(this).hide();
    })
});
// SHOW CLICK
$("#restore").click(function(){  
    $('img').show();   
});

$('p').click(function(){ 
    $('#mainphoto').fadeIn();
});

// FADE IN CLICK
    $("#fadein").click(function(){
      $("#div1").fadeIn();
      $("#div2").fadeIn("slow");
      $("#div3").fadeIn(4000);
    });

// FADE OUT CLICK
$("#fadeout").click(function(){
    $("#div3").fadeOut("fast");
    $("#div2").fadeOut(2000);
    $("#div1").fadeOut(4000);
  });

//HOVER ON AND AWAY TO CHANGE TEXT COLOR
$("h4").hover(function(){
    $(this).css("color", "blue");
    }, function(){
    $(this).css("color", "purple");
  });


//HOVER ON AND AWAY TO CHANGE HIGHLIGHT COLOR
$("h2").hover(function(){
    $(this).css("background-color", "pink");
    }, function(){
    $(this).css("background-color", "green");
  });

// APPEND

  $("#bappend").click(function(){
    $('p').append(" <b>Text Color</b>");
  });

//REPLACE TEXT


  $('.replace').hover(function(){
    $(this).text("I'm replaced!");
}, function() {
    $(this).text("Replace me please");
});


// SLIDE DOWN

$("#slide1").click(function(){
  $("#show1").slideDown("slow");
});
// SLIDE UP

$("#slide2").click(function(){
  $("#show2").slideDown("slow");
});

$("passHeader2").click(function(){
$(".slideU").slideUp("slow");
});    





  $(".flip").click(function(){
    $(".panel").slideUp("slow");
  });